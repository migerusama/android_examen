package com.example.ejercicio3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView texto;
    Button finalizar;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //Inicio las variables
        texto = findViewById(R.id.texto);
        finalizar = findViewById(R.id.bFinalizar);
        //Listener del boton
        finalizar.setOnClickListener(view -> {
            //Inicio la siguiente actividad
            Intent intent = new Intent(MainActivity2.this, ActivityFragments.class);
            startActivity(intent);
        });

        //Recojo los datos recibidos de la anterior actividad y los muestro
        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String direccion = intent.getStringExtra("direccion");
        texto.setText("Hola, "+nombre+", los datos enviados son los siguiente: "+direccion);
    }
}