package com.example.ejercicio2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView resultado;
    EditText numero1, numero2;
    Button multiplicar, dividir;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inizializarVariables();
    }

    @SuppressLint({"SetTextI18n", "NonConstantResourceId"})
    @Override
    public void onClick(View view) {
        //Recojo los datos
        String num1 = numero1.getText().toString(), num2 = numero2.getText().toString();
        switch (view.getId()) {
            case R.id.bMulti:
                //Compruebo si están vacios, en cuyo caso genero un toast
                if (num1.isEmpty() || num2.isEmpty()) generarToast(view);
                //Si no está vacío realizo la operacion de multiplicar
                else multiplicacion(num1, num2);
                break;
            case R.id.bDividir:
                //Compruebo si están vacios, en cuyo caso genero un toast
                if (num1.isEmpty() || num2.isEmpty()) generarToast(view);
                    //Si no está vacío realizo la operacion de division
                else resultado.setText("" + (Double.parseDouble(num1) / Double.parseDouble(num2)));
                break;
        }
    }

    @SuppressLint("SetTextI18n")
    private void multiplicacion(String num1, String num2) {
        //Creo el alertdialog
        builder.setMessage("¿Está seguro de querer realizar el cálculo?")
                .setCancelable(false)
                //Opcion SI
                .setPositiveButton("SI", (dialog, id) -> {
                    resultado.setText("" + (Double.parseDouble(num1) * Double.parseDouble(num2)));
                })
                //Opcion NO
                .setNegativeButton("NO", (dialog, id) -> {
                    numero1.setText("");
                    numero2.setText("");
                    resultado.setText("Resultado");
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    //Funcion para inicializar las variables
    private void inizializarVariables() {
        numero1 = findViewById(R.id.numero1);
        numero2 = findViewById(R.id.numero2);
        resultado = findViewById(R.id.resultado);
        multiplicar = findViewById(R.id.bMulti);
        dividir = findViewById(R.id.bDividir);
        multiplicar.setOnClickListener(this);
        dividir.setOnClickListener(this);
        builder = new AlertDialog.Builder(this);
    }

    //Funcion para generar el toast personalizado
    @SuppressLint("SetTextI18n")
    private void generarToast(View view) {
        LayoutInflater layoutInflater = getLayoutInflater();
        View inflater = layoutInflater.inflate(R.layout.custom_toast, view.findViewById(R.id.ll_custom_toast));
        TextView txtMensaje = inflater.findViewById(R.id.txtMensajeToast1);
        txtMensaje.setText("Introduzca datos válidos");
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(inflater);
        toast.show();
    }
}